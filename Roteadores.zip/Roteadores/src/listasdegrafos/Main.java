package listasdegrafos;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.util.Pair;

/**
 *
 * @author Jonathan Douglas Diego Tavares
 * @matricula 201622040228
 * @disciplina Laboratório de Algoritmos e Estrutura de Dados II
 */

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class Main {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        //declara variáveis necessárias
        AlgoritmosEmGrafos grafo; //grafo
        Scanner in = new Scanner(System.in); //instanciação de um scanner para leitura da entrada padrão
        int vertices, arestas; //declara variáveis necessárias

        int verticeInicial = 1; //vértice inicial do caminho mais curto

        //lê dois dados inteiros do arquivo aberto
        String linha = in.nextLine();
        String[] buffer = linha.split(" ", 2);

        vertices = Integer.parseInt(buffer[0]);
        arestas = Integer.parseInt(buffer[1]);

        //instância um objeto do tipo AlgoritmosEmGrafos
        grafo = new AlgoritmosEmGrafos(vertices + 1);

        //percorre arquivo lendo os dados e preenchendo o grafo com as arestas obtidas
        for (int i = 0; i < arestas; i++) {
            linha = in.nextLine();
            buffer = linha.split(" ", 3);
            int vertice1 = Integer.parseInt(buffer[0]);
            int vertice2 = Integer.parseInt(buffer[1]);
            int peso = Integer.parseInt(buffer[2]);

            //System.out.println("vertice1 = " + vertice1 + " - vertice2 = " + vertice2 + " - peso = " + peso);
            grafo.insereAresta(vertice1, vertice2, peso);
        }

        grafo.arvoreGeradoraMinima(verticeInicial);

        int total = 0;
        for (Pair<Integer, Integer> array : grafo.getArestasArvore()) {
            total = total + grafo.matrizAdjacencia[array.getKey()][array.getValue()];
        }

        System.out.println(total);
    }

    static class Grafo {

        //Atributos da classe
        protected final int numeroVertices;
        protected final int[][] matrizAdjacencia;

        /**
         * Método construtor, responsável por inicializar o número de vértices e
         * a matriz de adjacência
         *
         * @param vertices quantidade de vértices do grafo
         */
        public Grafo(int vertices) {
            numeroVertices = vertices;
            matrizAdjacencia = new int[numeroVertices][numeroVertices];
            inicializaMatrizAdj();
        }

        /**
         * Método auxiliar para colocar o valor 0 nas posições da matriz de
         * adjacência.
         */
        private void inicializaMatrizAdj() {
            for (int i = 0; i < numeroVertices; i++) {
                for (int j = 0; j < numeroVertices; j++) {
                    matrizAdjacencia[i][j] = 0;
                }
            }
        }

        /**
         * Método insereAresta, responsável por inserir uma aresta na matriz de
         * adjacência
         *
         * @param vertice1 vértice linha
         * @param vertice2 vértice coluna
         * @param peso peso da aresta
         */
        public void insereAresta(int vertice1, int vertice2, int peso) {
            //adiciona na posição [v1][v2] o valor do peso correspondente a aresta adicionada
            matrizAdjacencia[vertice1][vertice2] = peso;
        }

        /**
         * Método insereArestaNaoOrientada, responsável por inserir uma aresta
         * não orientada na matriz de adjacência
         *
         * @param vertice1
         * @param vertice2
         * @param peso
         */
        public void insereArestaNaoOrientada(int vertice1, int vertice2, int peso) {
            insereAresta(vertice1, vertice2, peso);
            insereAresta(vertice2, vertice1, peso);
        }

        /**
         * Método existeAresta, responsável por verificar se existe determinada
         * aresta na matriz de adjacência
         *
         * @param vertice1
         * @param vertice2
         * @return true se existir, false caso não exista
         */
        public boolean existeAresta(int vertice1, int vertice2) {
            return matrizAdjacencia[vertice1][vertice2] > 0;
        }

        /**
         * Método listaDeAdjacencia, responsável por retornar a lista de
         * adjacência obtida a partir da matriz
         *
         * @param vertice1
         * @return ArrayList contendo as adjacências de determinado vértice
         */
        ArrayList<Integer> listaDeAdjacencia(int vertice1) {
            ArrayList<Integer> listaAdj = new ArrayList();

            for (int i = 0; i < numeroVertices; i++) {
                if (matrizAdjacencia[vertice1][i] != 0) {
                    listaAdj.add(i);
                }
            }

            return listaAdj;
        }

        /**
         * Método getPeso, responsável por retornar o peso de uma aresta.
         *
         * @param vertice1
         * @param vertice2
         * @return o peso de determinada aresta contida na matriz
         */
        public int getPeso(int vertice1, int vertice2) {
            return this.matrizAdjacencia[vertice1][vertice2];
        }

        /**
         * Método imprimeMatrizAdj, responsável por realizar a impressão da
         * matriz de adjacência
         */
        public void imprimeMatrizAdj() {
            System.out.println("Matriz de adjacência:");
            for (int i = 0; i < numeroVertices; i++) {
                for (int j = 0; j < numeroVertices; j++) {
                    System.out.print(matrizAdjacencia[i][j] + " ");
                }
                System.out.println();
            }
        }

        /**
         * Método numVertices, responsável por retornar a quantidade de vértices
         * no grafo
         *
         * @return quantidade de vértices no grafo
         */
        public int numVertices() {
            return this.numeroVertices;
        }
    }

    static class AlgoritmosEmGrafos extends Grafo {

        //Atributos da classe
        private final int[] distanciaProfundidade; // vetor contendo as distâncias obtidas a partir da busca em profunidade
        private final int[] verticePredecessor; // vetor contendo os predecessores obtidos a partir da busca em profundidade
        private final int[] distanciasCMC;
        private final int[] verticeAntecessorCMC;
        private final MinHeap heapMin;
        private final ArrayList< Pair< Integer, Integer>> arestasArvoreGeradoraMinima;
        private final int[] verticeAntecessorAGM;
        private final int[] distanciasAGM;
        private final boolean[] visitados;

        /**
         * Método construtor, responsável por instanciar os vetores (atributos),
         * da classe
         *
         * @param vertices quantidade de vértices do grafo
         */
        public AlgoritmosEmGrafos(int vertices) {
            super(vertices);
            distanciaProfundidade = new int[vertices];
            verticePredecessor = new int[vertices];
            distanciasCMC = new int[vertices];
            verticeAntecessorCMC = new int[vertices];
            heapMin = new MinHeap(vertices);
            arestasArvoreGeradoraMinima = new ArrayList<>();
            verticeAntecessorAGM = new int[vertices];
            distanciasAGM = new int[vertices];
            visitados = new boolean[vertices];
        }

        /**
         * *********************************************************************
         * BUSCA EM PROFUNDIDADE
         * ********************************************************************
         */
        /**
         * Método iniciaBuscaEmProfundidade, responsável por inicializar os
         * vetores de distância e predecessores, e chamar a busca em
         * profundidade a partir de determinado vértice
         *
         * @param vertice vértice a partir de onde será realizada a busca
         */
        public void iniciaBuscaEmProfundidade(int vertice) {
            int tamanhoVetor = distanciaProfundidade.length;

            //Diz que a profundidade do vértice inicial é 0
            distanciaProfundidade[vertice] = 0;

            //Percorre o vetor de distâncias inicializando todas as posições com o valor V+1
            for (int i = 0; i < tamanhoVetor; i++) {
                if (!(i == vertice)) {
                    distanciaProfundidade[i] = tamanhoVetor + 1;
                }
                //diz que o predecessor não existe ainda
                verticePredecessor[i] = -1;
            }
            //chama a busca em profundidade
            buscaProfundidade(vertice);
        }

        /**
         * Método buscaProfundidade, responsável por realizar efetivamente a
         * busca a partir de um determinado vértice inicial
         *
         * @param vertice vértice inicial
         */
        private void buscaProfundidade(int vertice) {
            ArrayList<Integer> lista = listaDeAdjacencia(vertice);

            //Percorre a lista de adjacência
            for (int i = 0; i < lista.size(); i++) {
                //Se a distância é "infinito" então descobre o vértice e atualiza sua distância e seu predecessor
                if (distanciaProfundidade[lista.get(i)] == distanciaProfundidade.length + 1) {
                    distanciaProfundidade[lista.get(i)] = distanciaProfundidade[vertice] + 1;
                    verticePredecessor[lista.get(i)] = vertice;

                    //chama a busca em profundidade novamente, portanto o método é recursivo
                    buscaProfundidade(lista.get(i));
                }
            }
        }

        /**
         * Método getDistanciaProfundidade, resposável por retornar o vetor de
         * distâncias obtido na busca
         *
         * @return vetor de distância
         */
        public int[] getDistanciaProfundidade() {
            return this.distanciaProfundidade;
        }

        /**
         * Método getVerticePai, responsável por retornar o vetor de vértices
         * predecessores
         *
         * @return vetor de vértices predecessores
         */
        public int[] getVerticePai() {
            return verticePredecessor;
        }

        /**
         * Método getDistanciaVetorProf
         *
         * @return tamanho do vetor de distância
         */
        public int getDistanciaVetorProf() {
            return distanciaProfundidade.length;
        }

        /**
         * ********************************************************************
         */
        /**
         * *********************************************************************
         * DJIKSTRA
         * ********************************************************************
         */
        /**
         * Método inicializaDijkstra, responsável por inicializar os parâmetros
         * para o cálculo do menor caminho e construir o heap com os vértices do
         * grafo
         *
         * @param verticeInicial
         */
        private void inicializaDijkstra(int verticeInicial) {
            for (int i = 0; i < numVertices(); i++) {
                //Substituição do Integer.MAX_VALUE por 9999999
                //pois o MAX_VALUE estourava ao ser somado com mais
                //alguma coisa
                distanciasCMC[i] = 9999999;
                verticeAntecessorCMC[i] = -1;
            }

            distanciasCMC[verticeInicial] = 0;
            constroiHeapComVertices();
        }

        /**
         * Método iniciaCaminhoMaisCurto, responsável por chamar a função para
         * obter o caminho mais curto de um vértice inicial até os demais
         * vértices, porém retornando apenas a distância de vInicial até um
         * determinado vFinal
         *
         * @param verticeInicial
         * @param verticeFinal
         * @return distância de vInicial até vFinal
         */
        public int iniciaCaminhoMaisCurto(int verticeInicial, int verticeFinal) {
            inicializaDijkstra(verticeInicial);
            dijkstra(verticeInicial);
            return distanciasCMC[verticeFinal];
        }

        /**
         * Método iniciaCaminhoMaisCurto, responsável por chamar a função para
         * obter o caminho mais curto de um determinado vértice inicial até os
         * demais vérti ces
         *
         * @param verticeInicial
         * @return array contendo as distâncias obtidas
         */
        public int[] iniciaCaminhoMaisCurto(int verticeInicial) {
            inicializaDijkstra(verticeInicial);
            dijkstra(verticeInicial);
            return distanciasCMC;
        }

        /**
         * Método constroiHeapComVertices, responsável por inicializar o heap de
         * prioridade mínima com os vértices do grafo
         */
        private void constroiHeapComVertices() {
            for (int i = 0; i < numVertices(); i++) {
                heapMin.insert(i);
            }
            //heapMin.print();
        }

        /**
         * Método dijkstra, responsável por realizar o cálculo do menor caminho
         * entre um vértice inicial e os demais vértices do grafo
         *
         * @param verticeInicial
         */
        private void dijkstra(int verticeInicial) {
            //se heap não está vazio
            while (!heapMin.isEmpty()) {
                //obtém valor mínimo do heap
                int u = heapMin.remove();
                //System.out.println("u = " + u);
                //recupera lista de adjacência do vértice obtido do heap
                ArrayList<Integer> listaAdj = listaDeAdjacencia(u);

                //percorrre para todos os elementos na lista de adj
                for (int v = 0; v < listaAdj.size(); v++) {
                    //se a distância entre vértipublicce inicial até vértiec final é maior que a distância inicial + peso aresta 
                    if (distanciasCMC[listaAdj.get(v)] > distanciasCMC[u] + matrizAdjacencia[u][listaAdj.get(v)]) {
                        //atualiza a distância atual com o novo valor obtido
                        distanciasCMC[listaAdj.get(v)] = distanciasCMC[u] + matrizAdjacencia[u][listaAdj.get(v)];
                        //marca o antecessorpublic
                        verticeAntecessorCMC[listaAdj.get(v)] = u;
                    }
                }
            }
        }

        /**
         * Método getVerticeAntecessorCMC, responsável por obter os vértices
         * anteces sores
         *
         * @return array contendo os vértices antecessores
         */
        public int[] getVerticeAntecessorCMC() {
            return verticeAntecessorCMC;
        }

        /**
         * *********************************************************************
         * AGM
         * ********************************************************************
         */
        /**
         * return 0; Método iniciaArvoreGeradoraMinima, responsável por
         *
         * @param verticeInicial
         */
        public void inicializaArvoreGeradoraMinima(int verticeInicial) {
            for (int i = 0; i < numVertices(); i++) {
                //Substituição do Integer.MAX_VALUE por 9999999
                //pois o MAX_VALUE estourava ao ser somado com mais
                //alguma coisa
                distanciasAGM[i] = 9999999;
                verticeAntecessorAGM[i] = -1;
                visitados[i] = false;
            }

            distanciasAGM[verticeInicial] = 0;
            constroiHeapComVertices();

        }

        public void arvoreGeradoraMinima(int verticeInicial) {
            inicializaArvoreGeradoraMinima(verticeInicial);
            criaArvoreGeradoraMinima(verticeInicial);
        }

        private void criaArvoreGeradoraMinima(int verticeInicial) {
            while (!heapMin.isEmpty()) {
                //obtém valor mínimo do heap
                int u = heapMin.remove();
                //System.out.println("u = " + u);
                //recupera lista de adjacência do vértice obtido do heap
                ArrayList<Integer> listaAdj = listaDeAdjacencia(u);
                int escolhido = (!listaAdj.isEmpty()) ? 0 : -1;
                //percorrre para todos os elementos na lista de adj
                for (int v = 1; v < listaAdj.size(); v++) {
                    if (getPeso(u, listaAdj.get(v)) < getPeso(u, listaAdj.get(escolhido))) {
                        escolhido = v;
                    }
                }
                if (escolhido != -1) {
                    arestasArvoreGeradoraMinima.add(new Pair(u, listaAdj.get(escolhido)));
                }
                visitados[u] = true;
            }
        }

        public ArrayList< Pair< Integer, Integer>> getArestasArvore() {
            return arestasArvoreGeradoraMinima;
        }

        public int[] getVerticeAntecessorAGM() {
            return verticeAntecessorAGM;
        }

        public int[] getDistanciaAGM() {
            return distanciasAGM;
        }
        /**
         * *******************************************************************
         */
    }

    /*
    Algoritmo de implementação do Heap de prioridade mínima retirado do
    website GeeksForGeeks.

    Fonte: https://www.geeksforgeeks.org/min-heap-in-java/
     */
// Java implementation of Min Heap 
    static class MinHeap {

        private int[] Heap;
        private int size;
        private int maxsize;

        private static final int FRONT = 1;

        public MinHeap(int maxsize) {
            this.maxsize = maxsize;
            this.size = 0;
            Heap = new int[this.maxsize + 1];
            Heap[0] = Integer.MIN_VALUE;
        }

        // Function to return the position of 
        // the parent for the node currently 
        // at pos 
        private int parent(int pos) {
            return pos / 2;
        }

        // Function to return the position of the 
        // left child for the node currently at pos 
        private int leftChild(int pos) {
            return (2 * pos);
        }

        // Function to return the position of 
        // the right child for the node currently 
        // at pos 
        private int rightChild(int pos) {
            return (2 * pos) + 1;
        }

        // Function that returns true if the passed 
        // node is a leaf node 
        private boolean isLeaf(int pos) {
            if (pos >= (size / 2) && pos <= size) {
                return true;
            }
            return false;
        }

        // Function to swap two nodes of the heap 
        private void swap(int fpos, int spos) {
            int tmp;
            tmp = Heap[fpos];
            Heap[fpos] = Heap[spos];
            Heap[spos] = tmp;
        }

        // Function to heapify the node at pos 
        private void minHeapify(int pos) {

            // If the node is a non-leaf node and greater 
            // than any of its child 
            if (!isLeaf(pos)) {
                if (Heap[pos] > Heap[leftChild(pos)]
                        || Heap[pos] > Heap[rightChild(pos)]) {

                    // Swap with the left child and heapify 
                    // the left child 
                    if (Heap[leftChild(pos)] < Heap[rightChild(pos)]) {
                        swap(pos, leftChild(pos));
                        minHeapify(leftChild(pos));
                    } // Swap with the right child and heapify 
                    // the right child 
                    else {
                        swap(pos, rightChild(pos));
                        minHeapify(rightChild(pos));
                    }
                }
            }
        }

        // Function to insert a node into the heap 
        public void insert(int element) {
            if (size >= maxsize) {
                return;
            }
            Heap[++size] = element;
            int current = size;

            while (Heap[current] < Heap[parent(current)]) {
                swap(current, parent(current));
                current = parent(current);
            }
        }

        // Function to print the contents of the heap 
        public void print() {
            for (int i = 1; i < (size / 2); i++) {
                System.out.print(" PARENT : " + Heap[i]
                        + " LEFT CHILD : " + Heap[2 * i]
                        + " RIGHT CHILD :" + Heap[2 * i + 1]);
                System.out.println();
            }
        }

        // Function to build the min heap using 
        // the minHeapify 
        public void minHeap() {
            for (int pos = (size / 2); pos >= 1; pos--) {
                minHeapify(pos);
            }
        }

        // Function to remove and return the minimum 
        // element from the heap 
        public int remove() {
            int popped = Heap[FRONT];
            Heap[FRONT] = Heap[size--];
            minHeapify(FRONT);
            return popped;
        }

        //Função para testar se o heap está vazio
        public boolean isEmpty() {
            if (size == 0) {
                return true;
            }

            return false;
        }

        /**
         * Método contains, responsável por verificar se um elemento está
         * presente no Heap
         *
         * @param value
         * @return value está presente ou não no Heap
         */
        public boolean contains(int value) {
            for (int i = 0; i < Heap.length; i++) {
                if (value == Heap[i]) {
                    return true;
                }
            }

            return false;
        }
    }
}
