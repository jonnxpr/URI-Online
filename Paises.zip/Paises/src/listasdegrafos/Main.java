package listasdegrafos;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.util.Pair;

/**
 *
 * @author Jonathan Douglas Diego Tavares
 * @matricula 201622040228
 * @disciplina Laboratório de Algoritmos e Estrutura de Dados II
 */

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class Main {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        //declara variáveis necessárias
        AlgoritmosEmGrafos grafo; //grafo
        Scanner in = new Scanner(System.in); //instanciação de um scanner para leitura da entrada padrão
        int vertices, arestas, nConsultas; //declara variáveis necessárias
        ArrayList< Pair<Integer, Integer>> consultas;
        consultas = new ArrayList<>();

        int verticeInicial = 1; //vértice inicial do caminho mais curto

        //lê dois dados inteiros do arquivo aberto
        String linha = in.nextLine();
        String[] buffer = linha.split(" ", 2);
        vertices = Integer.parseInt(buffer[0]);
        arestas = Integer.parseInt(buffer[1]);

        do {
            //instância um objeto do tipo AlgoritmosEmGrafos
            grafo = new AlgoritmosEmGrafos(vertices + 2);
            //grafo.imprimeMatrizAdj();
            //percorre arquivo lendo os dados e preenchendo o grafo com as arestas obtidas
            for (int i = 0; i < arestas; i++) {
                linha = in.nextLine();
                buffer = linha.split(" ", 3);
                int vertice1 = Integer.parseInt(buffer[0]);
                int vertice2 = Integer.parseInt(buffer[1]);
                int peso = Integer.parseInt(buffer[2]);

                //System.out.println("vertice1 = " + vertice1 + " - vertice2 = " + vertice2 + " - peso = " + peso);
                grafo.insereAresta(vertice1, vertice2, peso);
            }
            //grafo.imprimeMatrizAdj();

            linha = in.nextLine();
            nConsultas = Integer.parseInt(linha);
            //System.out.println("nConsultas = " + nConsultas);
            for (int i = 0; i < nConsultas; i++) {
                linha = in.nextLine();
                buffer = linha.split(" ", 2);
                consultas.add(new Pair(Integer.parseInt(buffer[0]), Integer.parseInt(buffer[1])));
            }

            for (Pair<Integer, Integer> array : consultas) {
                //System.out.println(array.getKey() + " - " + array.getValue());
                int tempo = grafo.iniciaCaminhoMaisCurto(array.getKey(), array.getValue());
                System.out.println((tempo == 9999999) ? "Nao e possivel entregar a carta" : tempo);
            }

            System.out.println("");

            linha = in.nextLine();
            buffer = linha.split(" ", 2);
            vertices = Integer.parseInt(buffer[0]);
            arestas = Integer.parseInt(buffer[1]);
        } while (vertices != 0 && arestas != 0);

    }

    static class Grafo {

        //Atributos da classe
        protected final int numeroVertices;
        protected final int[][] matrizAdjacencia;

        /**
         * Método construtor, responsável por inicializar o número de vértices e
         * a matriz de adjacência
         *
         * @param vertices quantidade de vértices do grafo
         */
        public Grafo(int vertices) {
            numeroVertices = vertices;
            matrizAdjacencia = new int[numeroVertices][numeroVertices];
            inicializaMatrizAdj();
        }

        /**
         * Método auxiliar para colocar o valor 0 nas posições da matriz de
         * adjacência.
         */
        private void inicializaMatrizAdj() {
            for (int i = 0; i < numeroVertices; i++) {
                for (int j = 0; j < numeroVertices; j++) {
                    matrizAdjacencia[i][j] = 0;
                }
            }
        }

        /**
         * Método insereAresta, responsável por inserir uma aresta na matriz de
         * adjacência
         *
         * @param vertice1 vértice linha
         * @param vertice2 vértice coluna
         * @param peso peso da aresta
         */
        public void insereAresta(int vertice1, int vertice2, int peso) {
            //adiciona na posição [v1][v2] o valor do peso correspondente a aresta adicionada
            matrizAdjacencia[vertice1][vertice2] = peso;
        }

        /**
         * Método insereArestaNaoOrientada, responsável por inserir uma aresta
         * não orientada na matriz de adjacência
         *
         * @param vertice1
         * @param vertice2
         * @param peso
         */
        public void insereArestaNaoOrientada(int vertice1, int vertice2, int peso) {
            insereAresta(vertice1, vertice2, peso);
            insereAresta(vertice2, vertice1, peso);
        }

        /**
         * Método existeAresta, responsável por verificar se existe determinada
         * aresta na matriz de adjacência
         *
         * @param vertice1
         * @param vertice2
         * @return true se existir, false caso não exista
         */
        public boolean existeAresta(int vertice1, int vertice2) {
            return matrizAdjacencia[vertice1][vertice2] > 0;
        }

        /**
         * Método listaDeAdjacencia, responsável por retornar a lista de
         * adjacência obtida a partir da matriz
         *
         * @param vertice1
         * @return ArrayList contendo as adjacências de determinado vértice
         */
        ArrayList<Integer> listaDeAdjacencia(int vertice1) {
            ArrayList<Integer> listaAdj = new ArrayList();

            for (int i = 0; i < numeroVertices; i++) {
                if (matrizAdjacencia[vertice1][i] != 0) {
                    listaAdj.add(i);
                }
            }

            return listaAdj;
        }

        /**
         * Método getPeso, responsável por retornar o peso de uma aresta.
         *
         * @param vertice1
         * @param vertice2
         * @return o peso de determinada aresta contida na matriz
         */
        public int getPeso(int vertice1, int vertice2) {
            return this.matrizAdjacencia[vertice1][vertice2];
        }

        /**
         * Método imprimeMatrizAdj, responsável por realizar a impressão da
         * matriz de adjacência
         */
        public void imprimeMatrizAdj() {
            System.out.println("Matriz de adjacência:");
            for (int i = 0; i < numeroVertices; i++) {
                for (int j = 0; j < numeroVertices; j++) {
                    System.out.print(matrizAdjacencia[i][j] + " ");
                }
                System.out.println();
            }
        }

        /**
         * Método numVertices, responsável por retornar a quantidade de vértices
         * no grafo
         *
         * @return quantidade de vértices no grafo
         */
        public int numVertices() {
            return this.numeroVertices;
        }
    }

    static class AlgoritmosEmGrafos extends Grafo {

        //Atributos da classe
        private final int[] distanciaProfundidade; // vetor contendo as distâncias obtidas a partir da busca em profunidade
        private final int[] verticePredecessor; // vetor contendo os predecessores obtidos a partir da busca em profundidade
        private final int[] distanciasCMC;
        private final int[] verticeAntecessorCMC;
        private MinHeap heapMin;
        private final ArrayList< Pair< Integer, Integer>> arestasArvoreGeradoraMinima;
        private final int[] verticeAntecessorAGM;
        private final int[] distanciasAGM;
        private final boolean[] visitados;

        /**
         * Método construtor, responsável por instanciar os vetores (atributos),
         * da classe
         *
         * @param vertices quantidade de vértices do grafo
         */
        public AlgoritmosEmGrafos(int vertices) {
            super(vertices);
            distanciaProfundidade = new int[vertices];
            verticePredecessor = new int[vertices];
            distanciasCMC = new int[vertices];
            verticeAntecessorCMC = new int[vertices];
            //heapMin = new MinHeap(vertices);
            arestasArvoreGeradoraMinima = new ArrayList<>();
            verticeAntecessorAGM = new int[vertices];
            distanciasAGM = new int[vertices];
            visitados = new boolean[vertices];
        }

        /**
         * *********************************************************************
         * BUSCA EM PROFUNDIDADE
         * ********************************************************************
         */
        /**
         * Método iniciaBuscaEmProfundidade, responsável por inicializar os
         * vetores de distância e predecessores, e chamar a busca em
         * profundidade a partir de determinado vértice
         *
         * @param vertice vértice a partir de onde será realizada a busca
         */
        public void iniciaBuscaEmProfundidade(int vertice) {
            int tamanhoVetor = distanciaProfundidade.length;

            //Diz que a profundidade do vértice inicial é 0
            distanciaProfundidade[vertice] = 0;

            //Percorre o vetor de distâncias inicializando todas as posições com o valor V+1
            for (int i = 0; i < tamanhoVetor; i++) {
                if (!(i == vertice)) {
                    distanciaProfundidade[i] = tamanhoVetor + 1;
                }
                //diz que o predecessor não existe ainda
                verticePredecessor[i] = -1;
            }
            //chama a busca em profundidade
            buscaProfundidade(vertice);
        }

        /**
         * Método buscaProfundidade, responsável por realizar efetivamente a
         * busca a partir de um determinado vértice inicial
         *
         * @param vertice vértice inicial
         */
        private void buscaProfundidade(int vertice) {
            ArrayList<Integer> lista = listaDeAdjacencia(vertice);

            //Percorre a lista de adjacência
            for (int i = 0; i < lista.size(); i++) {
                //Se a distância é "infinito" então descobre o vértice e atualiza sua distância e seu predecessor
                if (distanciaProfundidade[lista.get(i)] == distanciaProfundidade.length + 1) {
                    distanciaProfundidade[lista.get(i)] = distanciaProfundidade[vertice] + 1;
                    verticePredecessor[lista.get(i)] = vertice;

                    //chama a busca em profundidade novamente, portanto o método é recursivo
                    buscaProfundidade(lista.get(i));
                }
            }
        }

        /**
         * Método getDistanciaProfundidade, resposável por retornar o vetor de
         * distâncias obtido na busca
         *
         * @return vetor de distância
         */
        public int[] getDistanciaProfundidade() {
            return this.distanciaProfundidade;
        }

        /**
         * Método getVerticePai, responsável por retornar o vetor de vértices
         * predecessores
         *
         * @return vetor de vértices predecessores
         */
        public int[] getVerticePai() {
            return verticePredecessor;
        }

        /**
         * Método getDistanciaVetorProf
         *
         * @return tamanho do vetor de distância
         */
        public int getDistanciaVetorProf() {
            return distanciaProfundidade.length;
        }

        /**
         * ********************************************************************
         */
        /**
         * *********************************************************************
         * DJIKSTRA
         * ********************************************************************
         */
        /**
         * Método inicializaDijkstra, responsável por inicializar os parâmetros
         * para o cálculo do menor caminho e construir o heap com os vértices do
         * grafo
         *
         * @param verticeInicial
         */
        private void inicializaDijkstra(int verticeInicial) {
            for (int i = 0; i < numVertices(); i++) {
                //Substituição do Integer.MAX_VALUE por 9999999
                //pois o MAX_VALUE estourava ao ser somado com mais
                //alguma coisa
                distanciasCMC[i] = 9999999;
                verticeAntecessorCMC[i] = -1;
            }

            distanciasCMC[verticeInicial] = 0;
            constroiHeapComVertices();
        }

        /**
         * Método iniciaCaminhoMaisCurto, responsável por chamar a função para
         * obter o caminho mais curto de um vértice inicial até os demais
         * vértices, porém retornando apenas a distância de vInicial até um
         * determinado vFinal
         *
         * @param verticeInicial
         * @param verticeFinal
         * @return distância de vInicial até vFinal
         */
        public int iniciaCaminhoMaisCurto(int verticeInicial, int verticeFinal) {
            inicializaDijkstra(verticeInicial);
            dijkstra(verticeInicial);
            return distanciasCMC[verticeFinal];
        }

        /**
         * Método iniciaCaminhoMaisCurto, responsável por chamar a função para
         * obter o caminho mais curto de um determinado vértice inicial até os
         * demais vérti ces
         *
         * @param verticeInicial
         * @return array contendo as distâncias obtidas
         */
        public int[] iniciaCaminhoMaisCurto(int verticeInicial) {
            inicializaDijkstra(verticeInicial);
            dijkstra(verticeInicial);
            return distanciasCMC;
        }

        /**
         * Método constroiHeapComVertices, responsável por inicializar o heap de
         * prioridade mínima com os vértices do grafo
         */
        private void constroiHeapComVertices() {
            ArrayList<Integer> lista = new ArrayList<>();
            for (int i = 0; i < numVertices(); i++) {
                lista.add(i);
            }
            heapMin = new MinHeap(lista);
            //heapMin.print();
        }

        /**
         * Método dijkstra, responsável por realizar o cálculo do menor caminho
         * entre um vértice inicial e os demais vértices do grafo
         *
         * @param verticeInicial
         */
        private void dijkstra(int verticeInicial) {
            //se heap não está vazio
            while (!heapMin.isEmpty()) {
                //obtém valor mínimo do heap
                int u = heapMin.extractMin();
                //System.out.println("u = " + u);
                //recupera lista de adjacência do vértice obtido do heap
                ArrayList<Integer> listaAdj = listaDeAdjacencia(u);

                //percorrre para todos os elementos na lista de adj
                for (int v = 0; v < listaAdj.size(); v++) {
                    //se a distância entre vértipublicce inicial até vértiec final é maior que a distância inicial + peso aresta 
                    if (distanciasCMC[listaAdj.get(v)] > distanciasCMC[u] + matrizAdjacencia[u][listaAdj.get(v)]) {
                        //atualiza a distância atual com o novo valor obtido
                        distanciasCMC[listaAdj.get(v)] = distanciasCMC[u] + matrizAdjacencia[u][listaAdj.get(v)];
                        //marca o antecessorpublic
                        verticeAntecessorCMC[listaAdj.get(v)] = u;
                    }
                }
            }
        }

        /**
         * Método getVerticeAntecessorCMC, responsável por obter os vértices
         * anteces sores
         *
         * @return array contendo os vértices antecessores
         */
        public int[] getVerticeAntecessorCMC() {
            return verticeAntecessorCMC;
        }

        /**
         * *********************************************************************
         * AGM
         * ********************************************************************
         */
        /**
         * return 0; Método iniciaArvoreGeradoraMinima, responsável por
         *
         * @param verticeInicial
         */
        public void inicializaArvoreGeradoraMinima(int verticeInicial) {
            for (int i = 0; i < numVertices(); i++) {
                //Substituição do Integer.MAX_VALUE por 9999999
                //pois o MAX_VALUE estourava ao ser somado com mais
                //alguma coisa
                distanciasAGM[i] = 9999999;
                verticeAntecessorAGM[i] = -1;
                visitados[i] = false;
            }

            distanciasAGM[verticeInicial] = 0;
            constroiHeapComVertices();

        }

        public void arvoreGeradoraMinima(int verticeInicial) {
            inicializaArvoreGeradoraMinima(verticeInicial);
            criaArvoreGeradoraMinima(verticeInicial);
        }

        private void criaArvoreGeradoraMinima(int verticeInicial) {
            while (!heapMin.isEmpty()) {
                //obtém valor mínimo do heap
                int u = heapMin.extractMin();
                //System.out.println("u = " + u);
                //recupera lista de adjacência do vértice obtido do heap
                ArrayList<Integer> listaAdj = listaDeAdjacencia(u);
                int escolhido = (!listaAdj.isEmpty()) ? 0 : -1;
                //percorrre para todos os elementos na lista de adj
                for (int v = 1; v < listaAdj.size(); v++) {
                    if (getPeso(u, listaAdj.get(v)) < getPeso(u, listaAdj.get(escolhido))) {
                        escolhido = v;
                    }
                }
                if (escolhido != -1) {
                    arestasArvoreGeradoraMinima.add(new Pair(u, listaAdj.get(escolhido)));
                }
                visitados[u] = true;
            }
        }

        public ArrayList< Pair< Integer, Integer>> getArestasArvore() {
            return arestasArvoreGeradoraMinima;
        }

        public int[] getVerticeAntecessorAGM() {
            return verticeAntecessorAGM;
        }

        public int[] getDistanciaAGM() {
            return distanciasAGM;
        }
        /**
         * *******************************************************************
         */
    }



    static class MinHeap {

        private ArrayList<Integer> list;

        public MinHeap() {

            this.list = new ArrayList<Integer>();
        }

        public MinHeap(ArrayList<Integer> items) {

            this.list = items;
            buildHeap();
        }

        public void insert(int item) {

            list.add(item);
            int i = list.size() - 1;
            int parent = parent(i);

            while (parent != i && list.get(i) < list.get(parent)) {

                swap(i, parent);
                i = parent;
                parent = parent(i);
            }
        }

        public void buildHeap() {

            for (int i = list.size() / 2; i >= 0; i--) {
                minHeapify(i);
            }
        }

        public int extractMin() {

            if (list.size() == 0) {

                throw new IllegalStateException("MinHeap is EMPTY");
            } else if (list.size() == 1) {

                int min = list.remove(0);
                return min;
            }

            // remove the last item ,and set it as new root
            int min = list.get(0);
            int lastItem = list.remove(list.size() - 1);
            list.set(0, lastItem);

            // bubble-down until heap property is maintained
            minHeapify(0);

            // return min key
            return min;
        }

        public void decreaseKey(int i, int key) {

            if (list.get(i) < key) {

                throw new IllegalArgumentException("Key is larger than the original key");
            }

            list.set(i, key);
            int parent = parent(i);

            // bubble-up until heap property is maintained
            while (i > 0 && list.get(parent) > list.get(i)) {

                swap(i, parent);
                i = parent;
                parent = parent(parent);
            }
        }

        private void minHeapify(int i) {

            int left = left(i);
            int right = right(i);
            int smallest = -1;

            // find the smallest key between current node and its children.
            if (left <= list.size() - 1 && list.get(left) < list.get(i)) {
                smallest = left;
            } else {
                smallest = i;
            }

            if (right <= list.size() - 1 && list.get(right) < list.get(smallest)) {
                smallest = right;
            }

            // if the smallest key is not the current key then bubble-down it.
            if (smallest != i) {

                swap(i, smallest);
                minHeapify(smallest);
            }
        }

        public int getMin() {

            return list.get(0);
        }

        public boolean isEmpty() {

            return list.size() == 0;
        }

        private int right(int i) {

            return 2 * i + 2;
        }

        private int left(int i) {

            return 2 * i + 1;
        }

        private int parent(int i) {

            if (i % 2 == 1) {
                return i / 2;
            }

            return (i - 1) / 2;
        }

        private void swap(int i, int parent) {

            int temp = list.get(parent);
            list.set(parent, list.get(i));
            list.set(i, temp);
        }

    }
}
